﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hotel.Modal
{
   public class RoomType
    {
       public int TypeID { get; set; }
       public string TypeName { get; set; }
    }
}
