﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hotel.Modal
{
   public class RoomInfo
    {
       public int roomeID { get; set; }
       public string Roomname { get; set; }
       public int roomePrice { get; set; }
       public string RoomDes { get; set; }
       public DateTime addTime { get; set; }
       public int joininday { get; set; }
       public int Totalprice { get; set; }
       public int buyState { get; set; }
       public int roomtypeID { get;set; }
    }
}
