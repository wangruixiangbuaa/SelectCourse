﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hotel.Modal
{
    public class Class1
    {
    }
}
