﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Hotel.BLL
{
   public class RoomInfoBLL
    {
       public static DataTable GetAllRoom()
       {
           return DAL.RoomInfoDAL.GetAllRoom();
       }
       public static int Delete(string id)
       {
           return DAL.RoomInfoDAL.Delete(id);
       }
       public static int Update(string id,int tian )
       {
           return DAL.RoomInfoDAL.Update(id,tian);
       }
       public static int Insert(string id, string name, int moeny, string jian, int ru, DateTime shi)
       {
           return DAL.RoomInfoDAL.Insert(id, name, moeny, jian, ru, shi);
       }
    }
}
