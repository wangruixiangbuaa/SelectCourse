﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Hotel.DAL
{
   public class RoomInfoDAL
    {
       public static DataTable GetAllRoom()
       {
           string sql = "select RoomInfo.*,TypeName from RoomType,RoomInfo where RoomInfo.roomtypeID=RoomType.TypeID";
           return SqlHelper.ExcuteTable(sql);
       }
       //删除
       public static int Delete(string id)
       {
           string sql = "delete from RoomInfo where roomeID=" + id;
           return SqlHelper.ExcuteNonQuery(sql);
       }
       //修改
       public static int Update(string id,int tian)
       { 
          
          string sql = string.Format("update RoomInfo set addTime='{0}',joininday={1},buyState=2 where roomeID={2}", DateTime.Now, tian, id);
          return SqlHelper.ExcuteNonQuery(sql);
       }
       //添加
       public static int Insert(string id, string name, int moeny, string jian, int ru, DateTime shi)
       {
           string sql = "insert into RoomInfo values({0},'{1}')";
           return SqlHelper.ExcuteNonQuery(sql);
       }
    }
}
