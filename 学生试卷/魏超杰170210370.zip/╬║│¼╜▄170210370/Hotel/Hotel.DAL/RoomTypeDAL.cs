﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Hotel.DAL
{
   public class RoomTypeDAL
    {
       public static DataTable GetAllRoomType()
       {
           string sql = "select * from RoomType";
           return SqlHelper.ExcuteTable(sql);
       }
    }
}
