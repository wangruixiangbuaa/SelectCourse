﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace Hotel.DAL
{
   public class SqlHelper
    {
       private static string conn = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
       public static DataTable ExcuteTable(string sql)
       {
           SqlConnection con = new SqlConnection(conn);
           SqlDataAdapter ads = new SqlDataAdapter(sql, con);
           DataTable table = new DataTable();
           ads.Fill(table);
           return table;
       }
       public static int ExcuteNonQuery(string sql)
       {
           SqlConnection con = new SqlConnection(conn);
           con.Open();
           SqlCommand cmd = new SqlCommand(sql, con);
           int i = cmd.ExecuteNonQuery();
           con.Close();
           return i;
       }
    }
}
