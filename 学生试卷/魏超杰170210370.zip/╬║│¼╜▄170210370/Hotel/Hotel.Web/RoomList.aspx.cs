﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hotel.Web
{
    public partial class RoomList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }
        public void BindData()
        {
            GridView1.DataSource = BLL.RoomInfoBLL.GetAllRoom();
            GridView1.DataBind();
        }
        //修改
        protected void Button2_Command(object sender, CommandEventArgs e)
        {
            int tian = 1;
            string id = e.CommandArgument.ToString();
            BLL.RoomInfoBLL.Update(id,tian);
            BindData();
        }
        //删除
        protected void Button3_Command(object sender, CommandEventArgs e)
        {
           
           
            string id = e.CommandArgument.ToString();
            BLL.RoomInfoBLL.Delete(id);
            BindData();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["Text"] = Button1.Text;
            Response.Redirect("AddRoom.aspx");
        }
    }
}