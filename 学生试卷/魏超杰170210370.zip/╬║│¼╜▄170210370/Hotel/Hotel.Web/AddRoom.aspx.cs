﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hotel.Web
{
    public partial class AddRoom : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                data();
            }
        }
        public void data()
        {
            DropDownList1.DataSource = BLL.RoomTypeBLL.GetAllRoomType();
            DropDownList1.DataTextField = "TypeName";
            DropDownList1.DataValueField = "TypeID";
            DropDownList1.DataBind();
            ListItem i = new ListItem();
            i.Text = "全部";
            i.Value = "0";
            DropDownList1.Items.Insert(0, i);
            DropDownList1.SelectedValue="0";

        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("RoomList.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string i = Session["id"].ToString();
            if (i == "添加房间信息")
            {
                TextBox3.Enabled = false;
                Calendar1.Enabled = false;
            }
           string id= DropDownList1.SelectedValue;
           string name = TextBox1.Text;
           int moeny = Convert.ToInt32(TextBox2.Text);
           string jian = TextBox3.Text;
           int ru = Convert.ToInt32(TextBox4.Text);
           DateTime shi = Convert.ToDateTime(Calendar1.SelectedDate);
            //非空验证
           if (id == "0")
           {
               Response.Write("<script>alert('请重新房间类别')</script>");
               return;
           }
           if (name == ""&&jian==""&&moeny == 0)
           {
               Response.Write("<script>alert('房间名称,简介,价格不能为空')</script>");
               return;
           }
           int rt = BLL.RoomInfoBLL.Insert(id, name, moeny, jian, ru, shi);
            if(rt>0)
            {
                Response.Write("<script>alert('添加成功')</script>");
            }
        }
    }
}