﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RoomWeb
{
    public partial class AddRoom : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["TypeID"] != null)
            {
                if (!IsPostBack)
                {
                    DataBind();

                }
                else
                {
                    Response.Redirect("RoomList.aspx");

                }

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string name = TextBox1.Text;
            string  day = TextBox4.Text;
           

        }

        protected void Button2_Click(object sender, EventArgs e)
        {




        }

        
    }
}