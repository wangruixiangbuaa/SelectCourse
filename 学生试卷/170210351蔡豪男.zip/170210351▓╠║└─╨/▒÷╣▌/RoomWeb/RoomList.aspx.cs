﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BAL;
using Model;
using System.Data;
using System.Data.SqlClient;


namespace RoomWeb
{
    public partial class RoomList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["TypeID"] != null)
            {
                if (!IsPostBack)
                {
                    Bind();

                }
                else {
                    Response.Redirect("AddRoom.aspx");
                
                }
            
            }

        }
        public void Bind()
        {
            DropDownList.DataSource = BAL.HotelBLL.GetAllHtole();
            DropDownList.DataTextFiled = "TypeID";
            DropDownList.DataValueFiled = "全部类型","0";
            DropDownList.DataBind = 0;

            ListItem item=new ListItem();
            ListItem.Items.Add(item);
            ListItem.SelectedValue();
           

            GridView1.DataSource = BAL.HotelBLL.GetAllHtole();
            GridView1.DataBind();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {




            GridView1.DataSource = BAL.HotelBLL.GetAllHtole();
            GridView1.DataBind();


        }
    }
}