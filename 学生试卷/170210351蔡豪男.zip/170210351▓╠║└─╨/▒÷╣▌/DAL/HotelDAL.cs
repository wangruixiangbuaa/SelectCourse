﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public class HotelDAL
    {
       public static List<Hotel> GetAllHtole()
       {
           DataTable table = new DataTable();
           

       }

       public static int ExexuteReader(Hotel hotel)
       {
           string sql=string.Format("select TypeName,buyState from RoomType,RoomInfo where RoomType.TypeID=RoomInfo.TypeID");

           List<Hotel> list = new List<Hotel>();

              foreach(int Rows)
              {
                  Hotel t = new Hotel();

                  t.Roomname = item["Roomname"].ToString;
                  t.TypeName = item["TypeName"].ToString;
                  t.joininday = Convert.ToInt32(item["joininday"]);
                  t.roomePrice = Convert.ToDecimal(item["roomePrice"]);
                  t.RoomDes = item["RoomDes"].ToString;addTime;
                 t.addTime = Convert.ToDateTime(item["addTime"]);
                     t.joininday = Convert.ToInt32(item["joininday"]);
                     t.buyState = Convert.ToInt32(item["buyState"]);
                     t.Totalprice = Convert.ToDecimal(item["Totalprice"]);

              return Add(t);
              }
           return list;
       }
       

    }
}
