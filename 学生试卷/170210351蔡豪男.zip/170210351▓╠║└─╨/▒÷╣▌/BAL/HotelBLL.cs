﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;
using Model;

namespace BAL
{
   public class HotelBLL
    {
       public static List<Hotel> GetAllHtole()
       {
           return DAL.HotelDAL.GetAllHtole();
       
       }

       public static int SqlDataReader (Hotel hotel)
       {
           return HotelBLL.ExecuteReader(hotel);
       
       }
       public static int ExexuteReader(Hotel hotel)
       {
           return HotelDAL.GetAllHtole(hotel);
       }

    }
}
