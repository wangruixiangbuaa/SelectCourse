﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Model
{
   public class Hotel
    {
        public string Roomname { get; set; }

        public string TypeName { get; set; }
        public decimal roomePrice { get; set; }
        public string RoomDes { get; set; }
        public DateTime addTime { get; set; }
        public int joininday { get; set; }
        public int buyState { get; set; }
        public decimal Totalprice { get; set; }
          
    }
}
