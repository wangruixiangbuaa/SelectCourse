﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Model
{
   public class SqlHelper
    {
       public static string constr=ConfigurationManager.ConnectionStrings["constr"].ConnectionString;

       public static SqlDataReader ExecuteReader(string sql)
       {
           SqlConnection conn = new SqlConnection(constr);
           conn.Open();
           SqlCommand cmd = new SqlCommand(conn,sql);

           SqlDataReader reader = new SqlDataReader();
           return reader;       
       
       }
       public static int ExecuteNonQuery(string sql)
       {
           SqlConnection conn = new SqlConnection(constr);
           conn.Open();
           SqlCommand cmd = new SqlCommand(conn, sql);

           int count = cmd.ExecuteNonQuery();
           return count;
       
       
       }

      
    }
}
