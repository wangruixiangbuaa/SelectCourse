prompt Importing table sm_p_function...
set feedback off
set define off
insert into sm_p_function (IFUNID, CFUNNAME, CFUNICON, CFUNSMALLICON, CFUNURL, CFUNONCLICK, IFUNORDER, IFUNFATHERID, IFUNMENUISSHOW, CFUNMENUORDER, TYPE, SQLID, PARAMS, ISBUTTON)
values (341627, '���ӷ�Ʊ����ӡ', '/img/da2.jpg', null, '/GetMoneyManage/EInvoiceLog/PayRedManageLog.aspx', null, null, 3001, 0, '946', null, null, null, 0);

prompt Done.
